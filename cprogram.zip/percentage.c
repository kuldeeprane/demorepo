#include <stdio.h>

int main(){
    printf("Percentage\n");
    printf("Enter marks of 5 subjects\n");
    int a, b, c, d, e;
    scanf("%d %d %d %d %d", &a, &b, &c, &d, &e);
    float total = a+b+c+d+e;
    float percentage = (total/500)*100;
    printf("Percentage: %.2f%%", percentage);
    return 0;
}